//
//  ContentView.swift
//  About Me App
//
//  Created by Sunny Moon on 7/27/23.
//

import SwiftUI

struct ContentView: View {
    
    @State private var aboutMe = ""
    @State private var image = "SunnyPic"
    @State private var buttonName = ""
    @State private var navigation = "Click here to learn more about me"
    
    
    var body: some View {
        ZStack{
            Color(.purple)
                .ignoresSafeArea()
            VStack(spacing: 20.0) {
                
                Text("Sunny Moon")
                    .font(.title)
                    .foregroundColor(Color.white)
                
                VStack{
                    Image(image)
                        .resizable(resizingMode: .stretch)
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                    
                    //                Image("celloPic")
                    //                    .resizable(resizingMode: .stretch)
                    //                    .aspectRatio(contentMode: .fit)
                    //                    .cornerRadius(20)
                    
                }
                .padding()
                .background(Color.white)
                .cornerRadius(20)
                
                Button(navigation){
                    navigate()
//                    aboutMe = "-rising HS junior from east bay area -cellist since 2018                                           -I like both working and having fun, but I prefer the latter"
//                    image = "celloPic"
                    
                }
                .buttonStyle(.borderedProminent)
                .font(.title2)
                .tint(.purple)
                .border(Color.white)
                
                
                Text(aboutMe)
                    .foregroundColor(.white)
                    .font(.title3)
                //            Button(buttonName){
                //                aboutMe = ""
                //                image = "SunnyPic"
                //                buttonName = ""
                //            }
                //            .foregroundColor(.white)
                //            .font(.title2)
                //            .tint(.purple)
            }
            .padding()
              
        }
    }
    func navigate() {
        if(image == "SunnyPic"){
            
            navigation = "🏠return home🏠"
            aboutMe = "-rising HS junior from east bay area -cellist since 2018                                           -I like both working and having fun, but I prefer the latter"
            image = "celloPic"
        }
        else{
            navigation = "Click here to learn more about me!"
            aboutMe = ""
            image = "SunnyPic"
        }
        }
}



struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
