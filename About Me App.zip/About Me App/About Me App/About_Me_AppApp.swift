//
//  About_Me_AppApp.swift
//  About Me App
//
//  Created by Sunny Moon on 7/27/23.
//

import SwiftUI

@main
struct About_Me_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
